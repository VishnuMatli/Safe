const express = require('express');
const bodyParser = require('body-parser');
const WebSocket = require('ws');
const https = require('https');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const authRoutes = require('./auth');

const app = express();

const httpsServerPort = 3000;
const staticServerPort = 4433;
const ipAddress = '100.76.187.58';

// Middleware
app.use(bodyParser.json());
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// Serve static files from the 'public' directory on a separate server instance
const staticServerOptions = {
    key: fs.readFileSync('cert.key'),
    cert: fs.readFileSync('cert.crt')
};
const staticServer = https.createServer(staticServerOptions, (req, res) => {
    const filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('File not found!');
            return;
        }
        res.writeHead(200);
        res.end(data);
    });
});
staticServer.listen(staticServerPort, () => {
    console.log(`Static HTTPS server running on https://${ipAddress}:${staticServerPort}`);
});

// Main Express/WebSocket server
const expressServerOptions = {
    key: fs.readFileSync('cert.key'),
    cert: fs.readFileSync('cert.crt')
};
const expressServer = https.createServer(expressServerOptions, app);

// MongoDB connection
mongoose.connect('mongodb+srv://sih:1234@safetourism.37en0mq.mongodb.net/tourist_app?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch(err => console.error('Could not connect to MongoDB Atlas', err));

app.use('/api/auth', authRoutes(bcrypt));

const wss = new WebSocket.Server({ server: expressServer });

wss.on('connection', ws => {
    console.log('New client connected');

    ws.on('message', message => {
        try {
            const data = JSON.parse(message);
            if (data.type === 'sos-alert') {
                console.log(`SOS Alert received from ${data.payload.id}. Broadcasting to all clients.`);
                wss.clients.forEach(client => {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify(data));
                    }
                });
            }
        } catch (error) {
            console.error('Failed to parse message:', error);
        }
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });

    ws.on('error', error => {
        console.error('WebSocket error:', error);
    });
});

expressServer.listen(httpsServerPort, () => {
    console.log(`Express server running on https://${ipAddress}:${httpsServerPort}`);
});